close all
clear
clc

edTh = 6; %wood1 - 8, lampshade1 - 6
cTh = 6000; %wood1 - 6000

im1 = imread('Results/Lampshade1/view1.png');
im1 = double(im1);
imL = 0.2989 * im1(:,:,1) + 0.5870 * im1(:,:,2) + 0.1140 * im1(:,:,3) ;

im2 = imread('Results/Lampshade1/view5.png');
im2 = double(im2);
imR = 0.2989 * im2(:,:,1) + 0.5870 * im2(:,:,2) + 0.1140 * im2(:,:,3) ;

imLy = edgeVert2(imL, edTh);
imLx = edgeHoriz2(imL, edTh);

imRx = edgeHoriz2(imR, edTh);
imRy = edgeVert2(imR, edTh);

Ly = imLy~=0;
Lx = imLx~=0;

Ry = imRy~=0;
Rx = imRx~=0;

[r, c] = size(imL);

imL = imL(8:r-7, 8:c-7);
imR = imR(8:r-7, 8:c-7);

imwrite(uint8(imL), ['Results/' num2str(cTh) '/Lampshade1/leftIm.jpg']);
imwrite(uint8(imR), ['Results/' num2str(cTh) '/Lampshade1/rightIm.jpg']);

figure, subplot(1,2,1), imagesc(Lx), colormap('gray');
subplot(1,2,2), imagesc(Rx), colormap('gray');
figure, subplot(1,2,1), imagesc(Ly), colormap('gray');
subplot(1,2,2), imagesc(Ry), colormap('gray');
figure, subplot(1,2,1), imagesc(imL), colormap('gray');
subplot(1,2,2), imagesc(imR), colormap('gray');

imwrite(Lx, 'Results/Lampshade1/leftEdg.jpg');
imwrite(Rx, 'Results/Lampshade1/rightEdg.jpg');

[r, c] = size(imLx);

[D, intraPrev] = intraS(Lx, Rx, imL, imR, cTh);
[dLR, dRL] = backTracking(intraPrev, imLx, Lx, Rx);

lMap = 255*(dLR - min(dLR(:)))/(max(dLR(:)) - min(dLR(:)));
rMap = 255*(dRL - min(dRL(:)))/(max(dRL(:)) - min(dRL(:)));
imwrite(uint8(lMap), 'Results/Lampshade1/map_left.jpg');
imwrite(uint8(rMap), 'Results/Lampshade1/map_right.jpg');
% for i = 1:1:r
%     [sum(Rx(i,:)) sum(Lx(i,:))]
% %     if sum(Rx(i,:))==0 || sum(Lx(i,:))==0
% %         disp(i)
% %     end
% end

