function [dMapLR, dMapRL] = backTracking(intraPrev, imLx, Lx, Rx)

for i = 1:1:size(intraPrev,2)
    prev = intraPrev{i};
    tmp = [prev(end, end, 2) prev(end, end, 1)];
    while tmp(1,1)~=1 || tmp(1,2)~=1
        tmp = [prev(tmp(1,1), tmp(1,2), 2) prev(tmp(1,1), tmp(1,2), 1);tmp];
    end
    path{i} = tmp;
end
dMapLR = zeros(size(imLx,1), size(imLx,2));
dMapRL = zeros(size(imLx,1), size(imLx,2));
for i = 1:1:size(path,2)
    p = path{i};
    m = find(Lx(i,:)~=0);
    n = find(Rx(i,:)~=0);
    
    if ~Lx(i,1)
        m = [1 m];
    end
    if ~Lx(i,end)
        m = [m size(Lx,2)];
    end
    if ~Rx(i,1)
        n = [1 n];
    end
    if ~Rx(i,end)
        n = [n size(Rx,2)];
    end
    for j = 1:1:size(p,1)-1
        if m(p(j,2)) == m(p(j+1,2))
            l = n(p(j+1,1)) - n(p(j,1)) + 1;
            dMapLR(i, m(p(j,2))) = m(p(j,2)) - mean(n(p(j,1)), n(p(j+1,1)));
            t1 = n(p(j,1)):1:n(p(j+1,1));
            t1 = t1 - m(p(j,2))*ones(1,l);
            dMapRL(i, n(p(j,1)):1:n(p(j+1,1))) = t1;
        elseif n(p(j,1)) == n(p(j+1,1))
            k = m(p(j+1,2)) - m(p(j,2)) + 1;
            t2 = m(p(j,2)):1:m(p(j+1,2));
            t2 = t2 - n(p(j,1))*ones(1,k);
            dMapLR(i, m(p(j,2)):m(p(j+1,2))) = t2;
            dMapRL(i, n(p(j,1))) = n(p(j,1)) - mean(m(p(j,2)), m(p(j+1,2)));
        else
            k = m(p(j+1,2)) - m(p(j,2)) + 1;
            l = n(p(j+1,1)) - n(p(j,1)) + 1;
            if k~=l
                m1 = m(p(j,2)):((k-1)/(l-1)):m(p(j+1,2));
                n1 = n(p(j,1)):((l-1)/(k-1)):n(p(j+1,1));
                t3 = m(p(j,2)):1:m(p(j+1,2));
                t3 = t3 - n1;
                dMapLR(i, m(p(j,2)):m(p(j+1,2))) = t3;
                t4 = n(p(j,1)):1:n(p(j+1,1));
                t4 = t4 - m1;
                dMapRL(i, n(p(j,1)):n(p(j+1,1))) = t4;
            else
                t5 = m(p(j,2)):1:m(p(j+1,2));
                t6 = n(p(j,1)):1:n(p(j+1,1));                
                dMapLR(i, m(p(j,2)):m(p(j+1,2))) = t5 - t6;
                dMapRL(i, n(p(j,1)):n(p(j+1,1))) = t6 - t5;
            end            
        end                        
    end
end

% figure, imagesc(dMapLR), colormap('gray');
% figure, imagesc(dMapRL), colormap('gray');