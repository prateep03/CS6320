function eM = edgeVert2(I, th)

[r, c, ~] = size(I);

f1 = [-0.5 0.5]';
f2 = [-1 -1 1 1]';
f2 = 0.25*f2;
f3 = [-2 -2 -2 -2 2 2 2 2]';
f3 = f3*(1/16);

% im1 = filter1d(I, f1);
im1 = conv2(I, f1, 'same');
l1 = abs(im1)>th;
e1 = im1.*l1;


% im2 = filter1d(I, f2);
im2 = conv2(I, f2, 'same');
l2 = abs(im2)>th;
e2 = im2.*l2;


% im3 = filter1d(I, f3);
im3 = conv2(I, f3, 'same');
l3 = abs(im3)>th;
e3 = im3.*l3;


eM = e1;


for j = 1:1:c
    for i = 3:1:r-2
        if abs(e2(i,j)) > 0
            if sum(abs(eM(i-2:1:i+2, j)))==0
                eM(i,j) = e2(i,j);
            end
        end
    end
end

for j = 1:1:c
    for i = 4:1:r-3
        if abs(e3(i,j)) > 0
            if sum(abs(eM(i-3:1:i+3, j)))==0
                eM(i,j) = e3(i,j);
            end
        end
    end
end

eM = eM(8:r-7, 8:c-7);
% eM = eM(4:r-3, 4:c-3);