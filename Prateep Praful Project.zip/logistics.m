im = imread('Results/wood1/view1.png');
im1 = im(8:size(im,1)-7, 8:size(im,2)-7, :);
im2 = imread('Results/wood1/view5.png');
im3 = im2(8:size(im2,1)-7, 8:size(im2,2)-7, :);
for i = 0:1:4
    if i == 0
        cTh = 1000;
    else
        cTh = 3000*i;
    end
    imwrite(im1, ['Results/' num2str(cTh) '/wood1/leftIm.jpg']);
    imwrite(im3, ['Results/' num2str(cTh) '/wood1/rightIm.jpg']);
end