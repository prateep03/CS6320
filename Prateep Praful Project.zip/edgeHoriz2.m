function eM = edgeHoriz2(I, th)

[r, c, ~] = size(I);

f1 = [-1 1];
f1 = 0.5*f1;
f2 = [-1 -1 1 1];
f2 = 0.25*f2;
f3 = [-2 -2 -2 -2 2 2 2 2];
f3 = f3*(1/16);

% im1 = filter1d(I, f1);
im1 = conv2(I, f1, 'same');
l1 = abs(im1)>th;
e1 = im1.*l1;


% im2 = filter1d(I, f2);
im2 = conv2(I, f2, 'same');
l2 = abs(im2)>th;

e2 = im2.*l2;


% im3 = filter1d(I, f3);
im3 = conv2(I, f3, 'same');
l3 = abs(im3)>th;
e3 = im3.*l3;

eM = e1;

for i = 1:1:r
    for j = 3:1:c-2
        if abs(e2(i,j)) > 0
            if sum(abs(eM(i, j-2:1:j+2)))==0
                eM(i,j) = e2(i,j);
            end
        end
    end
end
for i = 1:1:r
    for j = 4:1:c-3
        if abs(e3(i,j)) > 0
            if sum(abs(eM(i, j-3:1:j+3)))==0
                eM(i,j) = e3(i,j);
            end
        end
    end
end

eM = eM(8:r-7, 8:c-7);