function cst = cost(x, y, x2, y2, i,  lL, lR, imL, imR, cTh)

% lL = find(Lx~=0);
% lR = find(Rx~=0);
m1 = lL(x2);
m2 = lL(x);
n1 = lR(y2);
n2 = lR(y);

if x==x2
    n1 = lR(y2);
    n2 = lR(y);
    k = n2 - n1 + 1;
    t2 = std(imR(i, n1:n2), 1);
    
    if x == 1
        m1 = 1;
    else
        m1 = lL(x2-1);
    end
    
    m2 = lL(x2);
    l1 = m2 - m1 + 1;
    t1 = std(imL(i, m1:m2), 1);
    if l1 == 1
        s1 = 0;
    else        
        s1 = 0.5*(l1*t1^2 + k*t2^2)*sqrt(k^2 + l1^2);
    end
    
    if x == length(lL)
        m2 = size(imL,2);
    else
        m2 = lL(x2+1);
    end
    m1 = lL(x2);
    
    l2 = m2 - m1 + 1;
    t1 = std(imL(i, m1:m2), 1);
    if l2 == 1
        s2 = 0;
    else
        s2 = 0.5*(l2*t1^2 + k*t2^2)*sqrt(k^2 + l2^2);
    end
    
    s = (s1 + s2)*0.5;
    cst = k* (2*cTh - min(s, cTh));
elseif y==y2        
    m1 = lL(x2);
    m2 = lL(x);
    k = m2 - m1 + 1;
    t1 = std(imL(i, m1:m2), 1);
    
    if y == 1
        n1 = 1;
    else
        n1 = lR(y2-1);
    end
    
    n2 = lR(y);
    l1 = n2 - n1 + 1;
    t2 = std(imR(i, n1:n2), 1);
    if l1 == 1
        s1 = 0;
    else        
        s1 = 0.5*(k*t1^2 + l1*t2^2)*sqrt(k^2 + l1^2);
    end
    
    if y == length(lR)
        n2 = size(imR,2);
    else
        n2 = lR(y2+1);
    end
    
    n1 = lR(y2);
    l2 = n2 - n1 + 1;
    t2 = std(imR(i, n1:n2), 1);
    if l2 == 1
        s2 = 0;
    else
        s2 = 0.5*(k*t1^2 + l2*t2^2)*sqrt(k^2 + l2^2);
    end
    
    s = (s1 + s2)*0.5;
    cst = k* (2*cTh - min(s, cTh));
else
    s1 = std(imL(i, m1:m2), 1);
    k = m2 - m1 + 1;
    s2 = std(imR(i, n1:n2), 1);
    l = n2 - n1 + 1;
    cst = 0.5*(k*s1^2 + l*s2^2)*sqrt(k^2 + l^2);
end