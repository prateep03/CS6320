
function [dsp pixel_dsp segs labels] = total_stereo...
         (i1,i2, hs,hr,M,mins, maxs,win_size, segs, labels)
  
%   win_size = 2;  %-- larger for less textured surfaces
  tolerance = 0; %-- larger for less textured surfaces
  
  pthRs = 'Results/1000/wood1/';
  
  [dimy dimx c] = size(i1);
  [xx yy] = meshgrid(1:size(i1,2),1:size(i1,1));
  
  dsp  = ones(size(i1,1),size(i1,2));
  
  %--segment reference image
  if(nargin<9)
    [segs labels] = msseg(i1,hs,hr,M);  %-- mean shift segmentation
  end
  
%   %--determine pixel correspondence Right-to-Left
%   [disparity1 mindiff1] = slide_images(i1,i2, mins, maxs, win_size);
% 
%   %--determine pixel correspondence Left-to-Right
%   [disparity2 mindiff2] = slide_images(i2,i1, -mins, -maxs, win_size);
%   disparity2 = abs(disparity2); %-- disprities will be negative
  
  disparity1 = imread([pthRs 'map_left.jpg']);  %right image
  disparity2 = imread([pthRs 'map_right.jpg']);  %left image
  mindiff1 = zeros(size(disparity1));
  mindiff2 = zeros(size(disparity2));
  
  if size(disparity1,3) > 1,
      disparity1 = rgb2gray(disparity1);
  end
  
  if size(disparity2,3) > 1,
      disparity2 = rgb2gray(disparity2);
  end
 
  %--create high-confidence disparity map
  pixel_dsp = disparity1; 

  %--filter with segmented image
  for(i = 0:length(unique(labels))-1)
    lab_idx = find((labels == i));
    inf_idx = find(labels == i & pixel_dsp<inf);
    dsp(lab_idx) = median(pixel_dsp(inf_idx));
  end
  
  %--I think this looks cleaner, but it doesn't really serve a purpose
  pixel_dsp(pixel_dsp==inf)=NaN;
  dsp(isnan(dsp)) = 0;

  
%%----- HELPER FUNCTIONS

%-- slides images across each other to get disparity estimate
function [disparity mindiff] = slide_images(i1,i2,mins,maxs,win_size)
  [dimy,dimx,c] = size(i1);
  disparity = zeros(dimy,dimx);     %-- init outputs
  mindiff = inf(dimy,dimx);    
  w = 5;                            %-- weight of CSAD vs CGRAD
  hx = [-1 0 1]; hy = [-1 0 1]';    %-- gradient filter
  h = 1/win_size.^2*ones(win_size); %-- averaging filter

  g1x = sum(imfilter(i1,hx).^2,3);  %-- get gradient for each image
  g1y = sum(imfilter(i1,hy).^2,3);  %-- used to compute CGRAD
  g2x = sum(imfilter(i2,hx).^2,3);
  g2y = sum(imfilter(i2,hy).^2,3);
  
  step = sign(maxs-mins);             %-- adjusts to reverse slide
  for(i=mins:step:maxs)
    s  = shift_image(i2,i);         %-- shift image and derivs
    sx = shift_image(g2x,i);
    sy = shift_image(g2y,i);

    %--CSAD  is Cost from Sum of Absolute Differences
    %--CGRAD is Cost from Gradient of Absolute Differences
    diffs = sum(abs(i1-s),3);       %-- get CSAD and CGRAD
    CSAD  = imfilter(diffs,h);
    gdiff = w * (sum(abs(g1x-sx),3)+sum(abs(g1y-sy),3));
    CGRAD = imfilter(gdiff,h);
    d = CSAD+CGRAD;                 %-- total 'difference' score
    
    idx = find(d<mindiff);          %-- put corresponding disarity
    disparity(idx) = i;             %   into correct place in image
    mindiff(idx) = d(idx);
  end
  

%-- Shift an image
function I = shift_image(I,shift)
  dimx = size(I,2);
  if(shift > 0)
    I(:,shift:dimx,:) = I(:,1:dimx-shift+1,:);
    I(:,1:shift-1,:) = 0;
  else 
    if(shift<0)
      I(:,1:dimx+shift+1,:) = I(:,-shift:dimx,:);
      I(:,dimx+shift+1:dimx,:) = 0;
    end  
  end
  
  
  
