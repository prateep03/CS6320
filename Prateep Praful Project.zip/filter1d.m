function outp = filter1d(img, f)

img = double(img);
outp = zeros(size(img,1),size(img,2));

[s1, s2] = size(img);

lnth = length(f);
st = floor(lnth/2);

if size(f,1)>1 % vertical filter
    
    for x = st+1:1:s1-st
        wind = squeeze(img(x-st:x+st,1:s2));
        out1 = repmat(f,1,s2).*wind;
        outp(x,1:s2) = sum(out1);
    end
    
else
    
    for y = st+1:1:s2-st
        wind = squeeze(img(1:s1,y-st:y+st));
        out1 = repmat(f,s1,1).*wind;
        outp(1:s1,y) = sum(out1,2);
    end
        
end