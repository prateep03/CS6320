
%% Run this to demo stereo disparity extraction

addpath 'msseg';
pthRs = 'Results/1000/wood1/';
pthGt = 'Results/wood1/';
mins = 1;  %almost every time
maxs = 20; %depends on imagery
hs = 10;   %almost every time
hr = 7;    %almost every time
M = 30;    %almost every time

i1 = imread([pthRs 'rightIm.jpg']);  %right image
i2 = imread([pthRs 'leftIm.jpg']);  %left image


gt = imread([pthGt 'dispLeft_gt.jpg']);
gt = im2double(gt);
if size(gt,3) > 1,
    gt = rgb2gray(gt);
end
type = 'cc';

%-- here's the main call
for ws=5
%     fprintf('Win_size = %d',ws);
    [d p s l] = total_stereo(i1,i2, hs,hr,M,mins, maxs, ws);

%     %-- to match disparity with ground truth
%     off = 18;
%     mask = zeros(size(d));
%     mask(1:off,:) = 1;
%     mask(size(mask,1)-off+1:size(mask,1),:) = 1;
%     mask(:,1:off) = 1;
%     mask(:,size(mask,2)-off+1:size(mask,2)) = 1;

%     dt = d; % .* ~mask;

    %--  Display stuff
    f1 = figure;
    subplot(2,2,1), imshow(d,[]); title('disparity image');
    subplot(2,2,2); imshow(p,[]); title('pixel-wise disparity');
    subplot(2,2,3), imshow(s,[]); title('mean shift segmentation');
    subplot(2,2,4), imshow(i2); title('1st image');
    saveas(f1, [pthRs 'wood1LeftRes.eps'], 'psc2');
    %-- image difference
    [t, dif] = image_difference(d,gt,type);
    tt = norm(dif,'fro');
    fprintf('%.4f\n', tt);
end
% figure, imagesc(dif); axis off; colorbar;