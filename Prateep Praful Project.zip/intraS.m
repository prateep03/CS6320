function [DMat, prevMat] = intraS(Lx, Rx, imL, imR, cTh)

DMat = {};
prevMat = {};

[r, c] = size(Lx);

for i = 1:1:r
    disp(i)
    m = sum(Lx(i,:));
    n = sum(Rx(i,:));
    
    lL = find(Lx(i,:)~=0);
    lR = find(Rx(i,:)~=0);
    
    if ~Lx(i,1)
        m = m+1;
        lL = [1 lL];
    end
    if ~Lx(i,end)
        m = m+1;
        lL = [lL size(Lx,2)];
    end
    if ~Rx(i,1)
        n = n+1;
        lR = [1 lR];
    end
    if ~Rx(i,end)
        n = n+1;
        lR = [lR size(Rx,2)];
    end
    prev = zeros(n, m, 2);
    D = zeros(n, m);
    for x = 1:1:m
        for y = 1:1:n
            if x == 1 && y == 1
                continue;
            end
            minC = Inf;
            minPrev = [0 0];
            for x2 = 1:1:x
                for y2 = 1:1:y
                    if x2==x && y2==y
                        continue;
                    end
                    cst = cost(x, y, x2, y2, i, lL, lR, imL, imR, cTh);
                    if minC> (cst + D(y2,x2))
                        minC = cst + D(y2,x2);
                        minPrev = [x2, y2];
                    end
                end
            end
            D(y,x) = minC;
            prev(y,x,:) = minPrev;
        end
    end
    
    DMat = [DMat {D}];
    prevMat = [prevMat {prev}];
end